<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules
- All site content (status, mods, news, help, requirements, ranks, links) lives in `src/lib/site.ts`; pages only render it — so updates are one-file edits.
- Shared header/footer/status components are in `src/components/site.tsx`; page sections in `src/components/blocks.tsx`.
