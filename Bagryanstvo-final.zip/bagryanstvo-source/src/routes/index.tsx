import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero-island.jpg";
import { Btn, Section, StatusPanel, pageHead } from "@/components/site";
import { StepsList } from "@/components/blocks";
import { FEATURES, LINKS, PROGRESSION, SERVER_INFO, TEAM } from "@/lib/site";

export const Route = createFileRoute("/")({
  head: () => pageHead("Багрянство — хардкорный Vanilla-сервер Minecraft 1.21.11", "Хардкорный Vanilla-сервер Minecraft 1.21.11: кланы, фермы и механизмы. Статус сервера, IP и как начать играть."),
  component: Index,
});

function Index() {
  return (
    <>
      <section className="relative isolate overflow-hidden">
        <img src={hero} alt="Багровый остров на закате: башня, мельница и лагерь выживших" width={1920} height={1088} fetchPriority="high" className="absolute inset-0 -z-10 h-full w-full object-cover" />
        <div className="hero-overlay absolute inset-0 -z-10" />
        <div className="mx-auto grid max-w-6xl gap-8 px-4 pb-14 pt-24 sm:pt-36 lg:grid-cols-[1fr_360px] lg:items-end">
          <div>
            <p className="text-sm font-semibold uppercase tracking-widest text-accent">Vanilla 1.21.11 · Java</p>
            <h1 className="mt-3 text-4xl font-bold leading-tight sm:text-6xl">Багрянство</h1>
            <p className="mt-4 max-w-xl text-lg text-foreground/90">
              Хардкорное выживание на Vanilla 1.21.11: кланы и союзы, фермы и механизмы.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Btn to="/start">Как начать играть</Btn>
            </div>
          </div>
          <StatusPanel />
        </div>
      </section>

      <Section eyebrow="О сервере" title="Чем живёт сервер" intro="Багрянство — это хардкорное выживание, фермы и механизмы, кланы и союзы.">
        <dl className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {SERVER_INFO.map((i) => (
            <div key={i.k} className="rounded-lg border border-border bg-card p-4">
              <dt className="text-xs uppercase tracking-widest text-muted-foreground">{i.k}</dt>
              <dd className="mt-1 font-semibold">{i.v}</dd>
            </div>
          ))}
        </dl>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <article key={f.title} className="pixel-border rounded-lg bg-card p-5">
              <div className="text-3xl" aria-hidden>{f.icon}</div>
              <h3 className="mt-3 text-lg font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.text}</p>
            </article>
          ))}
        </div>
        <h3 className="mt-12 text-xl font-semibold">Путь развития</h3>
        <ol className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {PROGRESSION.map((p) => (
            <li key={p.stage} className="rounded-lg border-l-4 border-primary bg-card p-4">
              <p className="font-semibold">{p.stage}</p>
              <p className="mt-1 text-sm text-muted-foreground">{p.text}</p>
            </li>
          ))}
        </ol>
      </Section>

      <Section eyebrow="Установка" title="Как начать играть" intro="Четыре шага от запуска игры до первого входа на сервер.">
        <StepsList />
        <div className="mt-6"><Btn to="/start" variant="ghost">Подробная инструкция и требования →</Btn></div>
      </Section>

      <Section eyebrow="Ресурсы" title="Всё важное в одном месте">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { t: "Discord", d: "Общение, новости и тикеты поддержки", href: LINKS.discord },
          ].map((r) => (
            <a key={r.t} href={r.href} target="_blank" rel="noopener noreferrer" className="pixel-border block rounded-lg bg-card p-5 transition hover:border-accent">
              <h3 className="font-semibold">{r.t} ↗</h3>
              <p className="mt-1 text-sm text-muted-foreground">{r.d}</p>
            </a>
          ))}
          <Link to="/rules" className="pixel-border block rounded-lg bg-card p-5 transition hover:border-accent">
            <h3 className="font-semibold">Правила сервера</h3>
            <p className="mt-1 text-sm text-muted-foreground">Обязательно прочитайте перед игрой</p>
          </Link>
          <Link to="/help" className="pixel-border block rounded-lg bg-card p-5 transition hover:border-accent">
            <h3 className="font-semibold">Помощь и решение проблем</h3>
            <p className="mt-1 text-sm text-muted-foreground">Ошибки запуска, подключение, баг-репорты</p>
          </Link>
          <Link to="/about" hash="ranks" className="pixel-border block rounded-lg bg-card p-5 transition hover:border-accent">
            <h3 className="font-semibold">Привилегии</h3>
            <p className="mt-1 text-sm text-muted-foreground">Цены и условия — от 25 ₽</p>
          </Link>
          <a href={LINKS.partners} target="_blank" rel="noopener noreferrer" className="pixel-border block rounded-lg bg-card p-5 transition hover:border-accent">
            <h3 className="font-semibold">Партнёры ↗</h3>
            <p className="mt-1 text-sm text-muted-foreground">Каналы ютуберов проекта</p>
          </a>
        </div>
      </Section>

      <Section eyebrow="Проект" title="Команда Багрянства">
        <div className="grid gap-4 sm:grid-cols-3">
          {TEAM.map((t) => (
            <div key={t.role} className="rounded-lg border border-border bg-card p-5">
              <h3 className="font-semibold">{t.role}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{t.text}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          <Btn href={LINKS.discord}>Связаться в Discord</Btn>
          <Btn to="/about" variant="ghost">О проекте →</Btn>
        </div>
      </Section>
    </>
  );
}
