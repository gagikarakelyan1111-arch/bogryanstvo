import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Btn, Section, pageHead } from "@/components/site";
import { LINKS, RULES, RULES_INTRO } from "@/lib/site";

export const Route = createFileRoute("/rules")({
  head: () => pageHead("Правила сервера — Багрянство", "Правила сервера Багрянство: регистрация, чат, гриферство, разрешённое и запрещённое ПО, территории и кланы, постройки и наказания за нарушения."),
  component: Rules,
});

function Rules() {
  const [q, setQ] = useState("");
  const sections = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return RULES;
    return RULES.map((sec) => ({
      ...sec,
      rules: sec.rules.filter((r) => (r.id + " " + r.text + " " + (r.penalty ?? "")).toLowerCase().includes(s)),
      notes: sec.notes?.filter((n) => n.toLowerCase().includes(s)),
      lists: sec.lists?.map((l) => ({ ...l, items: l.items.filter((i) => i.toLowerCase().includes(s)) })).filter((l) => l.items.length > 0),
    })).filter((sec) => sec.rules.length > 0 || (sec.notes?.length ?? 0) > 0 || (sec.lists?.length ?? 0) > 0);
  }, [q]);

  return (
    <Section eyebrow="Обязательно к прочтению" title="Правила сервера" intro={RULES_INTRO}>
      <label htmlFor="rules-search" className="text-sm font-semibold">Поиск по правилам</label>
      <input id="rules-search" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Например: мут, дюп, территория, 3.4" className="mt-2 min-h-12 w-full rounded-md border-2 border-input bg-card px-4 text-base placeholder:text-muted-foreground focus:border-accent" />

      <nav aria-label="Разделы правил" className="mt-4 flex flex-wrap gap-2">
        {RULES.map((s) => (
          <a key={s.n} href={`#rules-${s.n}`} className="inline-flex min-h-11 items-center rounded-md border-2 border-border bg-card px-4 text-sm font-semibold hover:border-accent">
            {s.n}. {s.title}
          </a>
        ))}
      </nav>

      <div className="mt-8 space-y-10" aria-live="polite">
        {sections.length === 0 && <p className="rounded-lg border border-border bg-card p-5 text-muted-foreground">Ничего не найдено. Спросите в Discord — подскажем.</p>}
        {sections.map((sec) => (
          <section key={sec.n} id={`rules-${sec.n}`} aria-labelledby={`rules-title-${sec.n}`} className="scroll-mt-20">
            <h2 id={`rules-title-${sec.n}`} className="text-xl font-bold sm:text-2xl">
              <span className="mr-2 text-accent">{sec.n}.</span>{sec.title}
            </h2>
            <ol className="mt-4 space-y-3">
              {sec.rules.map((r) => (
                <li key={r.id} className="rounded-lg border-l-4 border-primary bg-card p-4">
                  <p><span className="mr-2 font-display font-bold text-accent">{r.id}</span>{r.text}</p>
                  {r.penalty && (
                    <p className="mt-2 text-sm"><span className="font-semibold text-warning">Наказание:</span> <span className="text-muted-foreground">{r.penalty}</span></p>
                  )}
                </li>
              ))}
            </ol>
            {sec.notes && sec.notes.length > 0 && (
              <div className="mt-4 rounded-lg border-2 border-warning bg-card p-4">
                <p className="font-semibold text-warning">Важно</p>
                <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                  {sec.notes.map((n) => <li key={n}>{n}</li>)}
                </ul>
              </div>
            )}
            {sec.lists && sec.lists.length > 0 && (
              <div className="mt-4 grid gap-4 lg:grid-cols-2">
                {sec.lists.map((l) => (
                  <div key={l.title} className={`rounded-lg border-2 bg-card p-4 ${l.kind === "deny" ? "border-destructive" : "border-success"}`}>
                    <p className={`font-semibold ${l.kind === "deny" ? "text-destructive" : "text-success"}`}>{l.kind === "deny" ? "⛔" : "✅"} {l.title}</p>
                    <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                      {l.items.map((i) => <li key={i}>{i}</li>)}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </section>
        ))}
      </div>

      <div className="mt-10 rounded-lg border-2 border-primary bg-card p-6">
        <h2 className="text-xl font-bold">Остались вопросы по правилам?</h2>
        <p className="mt-2 text-sm text-muted-foreground">Создайте тикет в Discord, и администрация ответит.</p>
        <div className="mt-4 flex flex-wrap gap-3">
          <Btn href={LINKS.discord}>Написать в Discord</Btn>
        </div>
      </div>
    </Section>
  );
}
