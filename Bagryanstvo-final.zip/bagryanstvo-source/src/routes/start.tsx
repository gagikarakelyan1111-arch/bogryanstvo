import { createFileRoute } from "@tanstack/react-router";
import { Btn, Section, StatusPanel, pageHead } from "@/components/site";
import { StepsList } from "@/components/blocks";
import { LINKS, REQUIREMENTS, START_INTRO } from "@/lib/site";

export const Route = createFileRoute("/start")({
  head: () => pageHead("Как начать играть — Багрянство", "Как запустить Minecraft 1.21.11, добавить сервер Багрянство и начать играть, а также системные требования."),
  component: Start,
});

function Start() {
  return (
    <>
      <Section eyebrow="Новичкам" title="Как начать играть" >
        <div className="mb-8 rounded-xl border-2 border-primary bg-card p-6">
          <p className="max-w-3xl text-lg leading-relaxed">{START_INTRO}</p>
          <div className="mt-5"><Btn href={LINKS.discord}>Вступить в Discord</Btn></div>
        </div>
        <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
          <StepsList />
          <div className="lg:sticky lg:top-20 lg:self-start"><StatusPanel /></div>
        </div>
      </Section>
      <Section id="requirements" eyebrow="Производительность" title="Системные требования" intro="Требования для Minecraft Java Edition 1.21.11.">
        <div className="overflow-x-auto rounded-lg border border-border">
          <table className="w-full min-w-[520px] text-left text-sm">
            <caption className="sr-only">Минимальные и рекомендуемые требования</caption>
            <thead className="bg-secondary">
              <tr><th scope="col" className="p-3">Компонент</th><th scope="col" className="p-3">Минимум</th><th scope="col" className="p-3">Рекомендуется</th></tr>
            </thead>
            <tbody>
              {REQUIREMENTS.map((r) => (
                <tr key={r.k} className="border-t border-border bg-card">
                  <th scope="row" className="p-3 font-semibold">{r.k}</th>
                  <td className="p-3 text-muted-foreground">{r.min}</td>
                  <td className="p-3">{r.rec}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div className="rounded-lg border border-border bg-card p-5">
            <h3 className="font-semibold">Нужна ли настройка</h3>
            <p className="mt-2 text-sm text-muted-foreground">На слабых ПК отключите шейдеры и поставьте прорисовку 8 чанков. На ноутбуках включите дискретную видеокарту для Java.</p>
          </div>
        </div>
      </Section>
    </>
  );
}
