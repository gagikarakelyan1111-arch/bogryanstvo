import { createFileRoute } from "@tanstack/react-router";
import { Btn, Section, pageHead } from "@/components/site";
import { CURRENCY, DONATIONS, HOW_TO_BUY, LINKS, TEAM } from "@/lib/site";

export const Route = createFileRoute("/about")({
  head: () => pageHead("О проекте и привилегии — Багрянство", "История и цели проекта Багрянство, роли администрации, контакты и честные условия привилегий."),
  component: About,
});

function About() {
  return (
    <>
      <Section eyebrow="О проекте" title="История и цели" intro="Багрянство создавалось как сервер, где выживание снова опасно, а каждое решение имеет цену.">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="rounded-lg border border-border bg-card p-5">
            <h3 className="font-semibold">Откуда мы</h3>
            <p className="mt-2 text-sm text-muted-foreground">Проект вырос из небольшого сервера для друзей в открытый Vanilla-сервер.</p>
          </div>
          <div className="rounded-lg border border-border bg-card p-5">
            <h3 className="font-semibold">Наши цели</h3>
            <p className="mt-2 text-sm text-muted-foreground">Стабильный сервер, регулярные обновления мира, честная игра без читов и события, ради которых хочется возвращаться.</p>
          </div>
        </div>
      </Section>
      <Section eyebrow="Администрация" title="Кто за всё отвечает">
        <div className="grid gap-4 sm:grid-cols-3">
          {TEAM.map((t) => (
            <div key={t.role} className="rounded-lg border border-border bg-card p-5"><h3 className="font-semibold">{t.role}</h3><p className="mt-1 text-sm text-muted-foreground">{t.text}</p></div>
          ))}
        </div>
        <div className="mt-6 rounded-lg border border-border bg-card p-5">
          <h3 className="font-semibold">Официальные контакты</h3>
          <p className="mt-2 text-sm text-muted-foreground">Единственный официальный канал связи — Discord. Вопросы, жалобы и баг-репорты принимаются через тикеты. Администрация никогда не просит пароль от аккаунта.</p>
          <div className="mt-4 flex flex-wrap gap-3"><Btn href={LINKS.discord}>Discord</Btn><Btn href={LINKS.partners} variant="ghost">Партнёры ↗</Btn></div>
        </div>
      </Section>
      <Section id="ranks" eyebrow="Поддержать проект" title="Привилегии" intro="Привилегии дают удобства и косметику. Деньги идут на оплату хостинга и развитие сервера.">
        <div className="mb-4 rounded-lg border-2 border-primary bg-card p-5">
          <h3 className="text-lg font-semibold">{CURRENCY.title}</h3>
          <p className="mt-1 font-display text-xl font-bold text-accent">{CURRENCY.text}</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {DONATIONS.map((d) => (
            <article key={d.name} className="pixel-border flex flex-col rounded-lg bg-card p-5">
              <div className="flex items-center gap-3">
                <span className="text-3xl" aria-hidden>{d.icon}</span>
                <h3 className="text-xl font-bold">{d.name}</h3>
              </div>
              <p className="mt-3 font-display text-2xl font-bold text-accent">{d.price} ₽ · навсегда</p>
              <p className="mt-3 text-sm">{d.intro}</p>
              {d.includes && <p className="mt-2 text-sm font-semibold text-accent">{d.includes}</p>}
              <ul className="mt-3 space-y-1.5 text-sm">
                {d.commands.map((c) => (
                  <li key={c.cmd}><code className="font-mono font-semibold text-accent">{c.cmd}</code> <span className="text-muted-foreground">{c.desc}</span></li>
                ))}
              </ul>
              {d.note && <p className="mt-3 text-sm text-muted-foreground">{d.note}</p>}
              {d.howToGet && (
                <div className="mt-3">
                  <p className="text-sm font-semibold">{d.howToGetTitle}</p>
                  <ul className="mt-1 list-disc space-y-1 pl-5 text-sm text-muted-foreground">{d.howToGet.map((h) => <li key={h}>{h}</li>)}</ul>
                </div>
              )}
              {d.warning && (
                <div className="mt-3 rounded-md border-2 border-warning p-3 text-sm">
                  <p className="font-semibold text-warning">ВАЖНО!</p>
                  <p className="mt-1">{d.warning}</p>
                </div>
              )}
              {LINKS.donate && <div className="mt-auto pt-4"><Btn href={LINKS.donate}>Купить</Btn></div>}
            </article>
          ))}
        </div>
        <ul className="mt-6 list-disc space-y-1 pl-5 text-sm text-muted-foreground">
          <li>Покупая привилегию, вы соглашаетесь с правилами сервера.</li>
          <li>Привилегия не защищает от наказаний за нарушения.</li>
          <li>Полный список возможностей каждого ранга указан выше.</li>
        </ul>
        <div className="mt-6 flex flex-wrap gap-3">{LINKS.donate && <Btn href={LINKS.donate}>Открыть магазин ↗</Btn>}<Btn to="/rules" variant="ghost">Правила →</Btn></div>
        <div className="mt-8 rounded-lg border border-border bg-card p-5">
          <h3 className="text-lg font-semibold">{HOW_TO_BUY.title}</h3>
          <ol className="mt-3 list-decimal space-y-1 pl-5 text-sm">
            {HOW_TO_BUY.steps.map((t) => <li key={t}>{t}</li>)}
          </ol>
          <div className="mt-4 rounded-md border-2 border-destructive p-3 text-sm">
            <p className="font-semibold text-destructive">ВАЖНО</p>
            <p className="mt-1 font-semibold">{HOW_TO_BUY.warning}</p>
          </div>
          {LINKS.donate && <div className="mt-4"><Btn href={LINKS.donate}>Перейти к оплате</Btn></div>}
        </div>
      </Section>
    </>
  );
}
