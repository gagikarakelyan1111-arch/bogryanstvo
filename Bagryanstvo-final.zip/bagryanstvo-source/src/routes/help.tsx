import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Btn, Section, pageHead } from "@/components/site";
import { HELP, LINKS } from "@/lib/site";

export const Route = createFileRoute("/help")({
  head: () => pageHead("Помощь — Багрянство", "Ошибки запуска, подключение к серверу, баг-репорты и связь с администрацией."),
  component: Help,
});

const CATS = Array.from(new Set(HELP.map((h) => h.cat)));

function Help() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<string | undefined>();
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return HELP.filter((h) => (!cat || h.cat === cat) && (!s || (h.q + " " + h.a).toLowerCase().includes(s)));
  }, [q, cat]);
  return (
    <Section eyebrow="Поддержка" title="Помощь и решение проблем">
      <label htmlFor="help-search" className="text-sm font-semibold">Поиск по вопросам</label>
      <input id="help-search" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Например: вылетает, память, подключение" className="mt-2 min-h-12 w-full rounded-md border-2 border-input bg-card px-4 text-base placeholder:text-muted-foreground focus:border-accent" />
      <div role="group" aria-label="Категории" className="mt-4 flex flex-wrap gap-2">
        {[undefined, ...CATS].map((c) => (
          <button key={c ?? "all"} onClick={() => setCat(c)} aria-pressed={cat === c} className={`min-h-11 rounded-md border-2 px-4 text-sm font-semibold ${cat === c ? "border-accent bg-accent text-accent-foreground" : "border-border bg-card hover:border-accent"}`}>
            {c ?? "Все"}
          </button>
        ))}
      </div>
      <div className="mt-6 space-y-3" aria-live="polite">
        {list.length === 0 && <p className="rounded-lg border border-border bg-card p-5 text-muted-foreground">Ничего не найдено. Задайте вопрос в Discord — поможем.</p>}
        {list.map((h) => (
          <details key={h.q} className="group rounded-lg border border-border bg-card">
            <summary className="flex min-h-12 cursor-pointer items-center justify-between gap-3 p-4 font-semibold">
              <span><span className="mr-2 text-xs text-accent">{h.cat}</span>{h.q}</span>
              <span aria-hidden className="transition group-open:rotate-45">+</span>
            </summary>
            <p className="px-4 pb-4 text-sm text-muted-foreground">{h.a}</p>
          </details>
        ))}
      </div>
      <div className="mt-10 rounded-lg border-2 border-primary bg-card p-6">
        <h2 className="text-xl font-bold">Не нашли ответ?</h2>
        <p className="mt-2 text-sm text-muted-foreground">Создайте тикет в Discord. Для баг-репорта приложите описание, скриншот и файл latest.log.</p>
        <div className="mt-4"><Btn href={LINKS.discord}>Написать в поддержку</Btn></div>
      </div>
    </Section>
  );
}
