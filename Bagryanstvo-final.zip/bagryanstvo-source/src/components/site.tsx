import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { LINKS, SERVER_IP, STATUS, type StatusLevel } from "@/lib/site";

const dot: Record<StatusLevel, string> = {
  online: "bg-success",
  maintenance: "bg-warning",
  offline: "bg-destructive",
};

export function StatusDot({ level }: { level: StatusLevel }) {
  return <span aria-hidden className={`inline-block h-2.5 w-2.5 rounded-full ${dot[level]} ${level === "online" ? "animate-pulse" : ""}`} />;
}

export function Btn({ to, href, children, variant = "primary", label }: { to?: string; href?: string; children: ReactNode; variant?: "primary" | "ghost"; label?: string }) {
  const cls =
    variant === "primary"
      ? "inline-flex min-h-11 items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 font-semibold text-primary-foreground glow transition hover:brightness-110"
      : "inline-flex min-h-11 items-center justify-center gap-2 rounded-md border-2 border-border bg-secondary px-5 py-2.5 font-semibold text-secondary-foreground transition hover:border-accent";
  if (to) { const [path, hash] = to.split("#"); return <Link to={path as "/"} hash={hash ?? ""} className={cls} aria-label={label}>{children}</Link>; }
  return <a href={href} target="_blank" rel="noopener noreferrer" className={cls} aria-label={label}>{children}</a>;
}

export function StatusPanel() {
  const rows = [STATUS.server];
  return (
    <section aria-labelledby="status-title" className="rounded-xl border-2 border-border bg-card/90 p-5 backdrop-blur">
      <h2 id="status-title" className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">Статус проекта</h2>
      <ul className="mt-3 space-y-3">
        {rows.map((r) => (
          <li key={r.label}>
            <div className="flex items-center gap-2 font-semibold"><StatusDot level={r.level} />{r.label}</div>
            <p className="ml-4.5 text-sm text-muted-foreground">{r.note}</p>
          </li>
        ))}
      </ul>
      <dl className="mt-4 grid grid-cols-1 gap-3 border-t border-border pt-3 text-sm">
        <div><dt className="text-muted-foreground">Версия</dt><dd className="font-medium">{STATUS.version}</dd></div>
        <div><dt className="text-muted-foreground">IP сервера</dt><dd className="select-all break-all font-mono font-medium">{SERVER_IP}</dd></div>
      </dl>
      <a href={LINKS.discord} target="_blank" rel="noopener noreferrer" className="mt-4 inline-flex min-h-11 items-center font-semibold text-accent underline-offset-4 hover:underline">
        Наш Discord →
      </a>
    </section>
  );
}

export function Section({ id, eyebrow, title, intro, children }: { id?: string; eyebrow?: string; title: string; intro?: string; children: ReactNode }) {
  return (
    <section id={id} className="mx-auto max-w-6xl scroll-mt-20 px-4 py-14 sm:py-20">
      {eyebrow && <p className="text-sm font-semibold uppercase tracking-widest text-accent">{eyebrow}</p>}
      <h2 className="mt-2 text-2xl font-bold sm:text-4xl">{title}</h2>
      {intro && <p className="mt-3 max-w-2xl text-muted-foreground">{intro}</p>}
      <div className="mt-8">{children}</div>
    </section>
  );
}

const NAV = [
  { group: "Новичкам", items: [
    { label: "Как начать играть", to: "/start" },
    { label: "Системные требования", to: "/start#requirements" },
    { label: "Правила сервера", to: "/rules" },
  ]},
  { group: "Игрокам", items: [
    { label: "Помощь", to: "/help" },
  ]},
  { group: "О проекте", items: [
    { label: "Команда и контакты", to: "/about" },
    { label: "Привилегии", to: "/about#ranks" },
    { label: "Партнёры", href: LINKS.partners },
  ]},
];

function NavItem({ i, onClick }: { i: { label: string; to?: string; href?: string }; onClick?: (() => void) | undefined }) {
  const cls = "block rounded px-3 py-2.5 text-sm hover:bg-secondary";
  const [path, hash] = (i.to ?? "").split("#");
  return i.to ? (
    <Link to={path as "/"} hash={hash ?? ""} className={cls} onClick={onClick}>{i.label}</Link>
  ) : (
    <a href={i.href} target="_blank" rel="noopener noreferrer" className={cls}>{i.label} ↗</a>
  );
}

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:rounded focus:bg-accent focus:px-3 focus:py-2 focus:text-accent-foreground">К содержимому</a>
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
        <Link to="/" className="font-display text-lg font-bold tracking-tight">Багрянство</Link>
        <nav aria-label="Основная навигация" className="hidden items-center gap-1 lg:flex">
          {NAV.map((g) => (
            <div key={g.group} className="group relative">
              <button className="min-h-11 rounded px-3 text-sm font-medium hover:bg-secondary" aria-haspopup="true">{g.group} ▾</button>
              <div className="invisible absolute left-0 top-full w-60 rounded-lg border border-border bg-popover p-2 opacity-0 shadow-xl transition group-focus-within:visible group-focus-within:opacity-100 group-hover:visible group-hover:opacity-100">
                {g.items.map((i) => <NavItem key={i.label} i={i} />)}
              </div>
            </div>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/start" className="hidden min-h-11 items-center rounded-md bg-primary px-4 text-sm font-semibold text-primary-foreground sm:inline-flex">Начать играть</Link>
          <button className="min-h-11 min-w-11 rounded-md border border-border lg:hidden" aria-expanded={open} aria-controls="mobile-nav" aria-label={open ? "Закрыть меню" : "Открыть меню"} onClick={() => setOpen(!open)}>
            {open ? "✕" : "☰"}
          </button>
        </div>
      </div>
      {open && (
        <nav id="mobile-nav" aria-label="Мобильная навигация" className="max-h-[80vh] overflow-y-auto border-t border-border px-4 pb-4 lg:hidden">
          <Link to="/start" onClick={() => setOpen(false)} className="mt-3 flex min-h-11 items-center justify-center rounded-md bg-primary font-semibold text-primary-foreground">Начать играть</Link>
          {NAV.map((g) => (
            <div key={g.group} className="mt-3">
              <p className="px-3 text-xs font-semibold uppercase tracking-widest text-muted-foreground">{g.group}</p>
              {g.items.map((i) => <NavItem key={i.label} i={i} onClick={() => setOpen(false)} />)}
            </div>
          ))}
        </nav>
      )}
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-display text-lg font-bold">Багрянство</p>
          <p className="mt-2 text-sm text-muted-foreground">Хардкорный Vanilla-сервер Minecraft 1.21.11. Не является официальным продуктом Mojang.</p>
          <a href={LINKS.discord} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex min-h-11 items-center font-semibold text-accent hover:underline">Discord ↗</a>
        </div>
        {NAV.map((g) => (
          <div key={g.group}>
            <p className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">{g.group}</p>
            <div className="-mx-3 mt-2">{g.items.map((i) => <NavItem key={i.label} i={i} />)}</div>
          </div>
        ))}
      </div>
    </footer>
  );
}

export function pageHead(title: string, description: string) {
  return {
    meta: [
      { title },
      { name: "description", content: description },
      { property: "og:title", content: title },
      { property: "og:description", content: description },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  };
}
