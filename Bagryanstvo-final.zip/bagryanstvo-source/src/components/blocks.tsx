import { Link } from "@tanstack/react-router";
import { STEPS } from "@/lib/site";

export function StepsList() {
  return (
    <ol className="space-y-3">
      {STEPS.map((s, i) => (
        <li key={s.title} className="flex flex-col gap-3 rounded-lg border border-border bg-card p-5 sm:flex-row sm:items-center">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary font-display font-bold text-primary-foreground">{i + 1}</span>
          <div className="flex-1">
            <h3 className="font-semibold">{s.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
            {s.ip && <code className="mt-2 inline-block select-all break-all rounded bg-secondary px-2 py-1 font-mono text-sm text-accent">{s.ip}</code>}
          </div>
          {s.href && s.cta && (
            <div className="shrink-0">
              {s.internal ? (() => { const [p, h] = s.href.split("#"); return <Link to={p as "/"} hash={h ?? ""} className="inline-flex min-h-11 items-center rounded-md border-2 border-border px-4 font-semibold hover:border-accent">{s.cta}</Link>; })() : (
                <a href={s.href} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-11 items-center rounded-md border-2 border-border px-4 font-semibold hover:border-accent">{s.cta} ↗</a>
              )}
            </div>
          )}
        </li>
      ))}
    </ol>
  );
}
